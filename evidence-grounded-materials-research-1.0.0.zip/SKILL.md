---
name: evidence-grounded-materials-research
description: "Design evidence-grounded materials-science research plans for any user-specified material system. Use when a user asks for a literature-backed experimental plan, characterization matrix, mechanism analysis, innovation assessment, paper outline, control strategy, or research roadmap for materials synthesis, processing, interfaces, coatings, catalysts, energy materials, tribology, corrosion, polymers, ceramics, metals, composites, or related systems. Require verifiable scholarly sources and never invent citations, DOI values, data, mechanisms, novelty, or experimental conditions."
license: MIT
slug: "evidence-grounded-materials-research"
version: "1.0.0"
displayName: "循证材料研究设计"
summary: "基于可核验文献，为任意材料体系生成实验、表征、机理、创新点与论文方案。"
tags: ["materials-science", "literature-review", "experiment-design", "characterization", "scientific-writing"]
---

# 循证材料研究设计

## 任务

把用户给出的任意材料体系转化为可执行、可证伪、可追溯的研究设计。先检索和核验文献，再生成实验方案、表征方案、机理假设、创新点评估和论文框架。

不得伪造论文、作者、期刊、年份、卷页、DOI、实验数据或“首次发现”等结论。无法核验的内容必须标为“待核验”或“工作假设”，并说明需要什么证据才能升级为结论。

## 适用场景与触发条件

在用户提供材料、组分、界面、制备工艺或目标性能，并要求下列任一内容时使用：

- 设计实验、对照、变量、重复和评价指标；
- 规划结构、成分、界面、性能或原位表征；
- 从文献建立机理假设或提出证伪实验；
- 评估研究空白、创新性、可行性和证据风险；
- 生成论文逻辑、图表规划或研究路线图；
- 审核现有研究方案是否有文献依据。

不要用于替代实验室安全审批、设备 SOP、医学建议或未经验证的工程放大决策。

## 输入要求

至少获取：

1. `material_system`：材料、组分、形态或界面；
2. `research_goal`：目标性能、科学问题或应用场景。

尽量获取：制备条件、可用设备、基线样、约束、评价标准、已有数据、目标期刊和时间/成本限制。缺少会改变研究方向的关键信息时，最多提出 3 个高价值问题；其余假设写入“边界与假设”。

结构化输入可先运行：

```bash
python scripts/validate_input.py examples/sample-input.json
```

## 强制证据门禁

1. 先读取 [references/evidence-policy.md](references/evidence-policy.md)，执行检索、来源分级和元数据核验。
2. 至少建立“主张—来源—适用边界—置信度”证据表，再写实验方案。
3. 每个关键参数必须属于以下之一：
   - 有直接文献依据，并标注来源；
   - 来自相邻体系的可解释外推，并标注外推风险；
   - 仅作为筛选起点，并标注“工程起始值/待优化”。
4. 不能访问文献或不能核验来源时，停止生成确定性方案；只输出检索式、候选数据库、待验证假设和信息缺口。
5. 不以搜索摘要代替论文证据。摘要可用于筛选，但关键主张应回到出版商页面、数据库记录、全文或补充材料核验。

## 工作流程

### 1. 定义问题与边界

规范材料名称、组成、形态、处理历史、环境和目标响应。区分用户已知事实、文献事实、推断和未知项。

### 2. 检索并核验文献

用材料别名、化学式、工艺、性能、机理和表征方法构建多组检索式。优先使用同行评议原始研究，再用高质量综述建立领域地图。对 DOI、题名、作者、期刊和年份做交叉核验。

### 3. 建立证据地图

为每条关键主张分配 `E1`、`E2` 等证据编号，记录直接性、来源类型、适用边界和置信度。冲突文献必须并列呈现并解释可能原因。

### 4. 设计实验

读取 [references/experimental-design-guardrails.md](references/experimental-design-guardrails.md)。把每个假设映射到因素、水平、对照、响应、重复、统计方法、成功标准和失败后的下一步。先安排低成本筛选，再安排高成本验证。

### 5. 设计表征矩阵

对每个科学问题列出：表征方法、样品状态、测量条件、预期可观察量、支持哪条假设、不能证明什么、互证方法和伪影风险。不要把单一表征当作完整机理证明。

### 6. 分析机理并设计证伪

同时提出主假设和至少一个竞争假设。使用“现象 → 中间证据 → 因果主张”的链条，明确相关性与因果性的区别。为每个机理给出能使其失败的实验结果。

### 7. 评估创新点

把创新拆为材料组合、界面调控、制备窗口、表征方法、机理证据或应用指标。与最接近文献逐项比较。没有系统检索证据时，不得使用“首次”“唯一”“颠覆性”等绝对表述。

### 8. 构建论文框架

按“研究缺口 → 假设 → 设计 → 证据 → 机理 → 边界”组织摘要、引言、结果与讨论、方法、局限和结论。每幅拟议图都要回答一个明确问题。

### 9. 审计输出

按 [references/output-contract.md](references/output-contract.md) 生成报告，并运行：

```bash
python scripts/audit_output.py path/to/report.md --min-sources 3
```

修复所有错误。警告项必须人工复核或在报告中解释。

## 输出格式

使用 Markdown，固定包含以下一级内容：

1. 研究问题与边界；
2. 文献证据表；
3. 证据缺口与置信度；
4. 实验方案；
5. 表征方案；
6. 机理假设与证伪；
7. 创新点评估；
8. 论文框架；
9. 安全与局限；
10. 已核验参考文献。

在结论旁使用证据编号，如 `[E2]`。参考文献至少给出题名、作者、期刊/来源、年份和可解析 DOI 或稳定数据库链接。详细字段见 [references/output-contract.md](references/output-contract.md)。

## 使用方法

用户可直接描述：

> 我的材料体系是……，目标是……，现有设备包括……。请给出有文献依据的实验和表征方案，并分析机理、创新点及论文结构。

也可提供基于 [assets/intake-template.md](assets/intake-template.md) 填写的结构化需求。生成报告时复制 [assets/research-report-template.md](assets/research-report-template.md) 作为骨架。

## 示例

查看：

- [examples/sample-input.json](examples/sample-input.json)：示例输入；
- [examples/sample-report.md](examples/sample-report.md)：带真实可核验 DOI、但仅用于演示格式的缩略报告。

示例不能直接替代针对用户材料体系的重新检索与验证。
