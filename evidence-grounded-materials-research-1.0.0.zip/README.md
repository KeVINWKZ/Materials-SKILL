# 循证材料研究设计

面向任意材料体系的 AI Skill。它要求 Agent 在生成实验方案、表征矩阵、机理分析、创新点和论文框架之前，先检索并核验文献；无法验证的内容必须标为假设或证据缺口。

## 发布信息

- Skill 名称：循证材料研究设计
- Slug：`evidence-grounded-materials-research`
- 简介：基于可核验文献，为任意材料体系生成可执行、可证伪、可追溯的研究方案。
- 关键词：材料科学、文献检索、实验设计、表征方案、机理分析、创新点、论文写作
- 版本：`1.0.0`
- 许可证：MIT

## 能力

- 从用户材料体系和研究目标构建检索策略；
- 核验 DOI/题名/作者/期刊/年份并建立证据表；
- 生成包含对照、变量、重复、统计和停止条件的实验路线；
- 将表征方法映射到假设、可观察量、局限和互证；
- 同时提出主机理与竞争机理，并设计证伪实验；
- 评估候选创新点，禁止无证据的“首次”宣传；
- 生成论文论证链、章节框架和图表规划。

## 安装测试

复制整个目录到 Agent 的 skills 目录，或在项目中直接引用 `SKILL.md`。本项目脚本仅依赖 Python 3 标准库。

```bash
python scripts/validate_input.py examples/sample-input.json
python scripts/audit_output.py examples/sample-report.md --min-sources 3
```

审计脚本也支持从标准输入读取 Markdown：`python scripts/audit_output.py -`。

生成 SkillHub 上传包：

```bash
python scripts/package_skill.py .
skillhub publish dist/evidence-grounded-materials-research-1.0.0.zip --dry-run
```

## 使用示例

> 使用循证材料研究设计 Skill。我的材料体系是“某基体 + 某增强相/界面改性剂”，目标是提高某性能。请先核验直接文献，再给出实验方案、表征矩阵、机理竞争假设、创新点评估和论文框架；无法验证的内容必须标为假设。

## 作者介绍

本 Skill 由 SkillHub 发布账户维护，面向材料科研人员、研究生和研发工程师，强调证据追溯、可证伪实验与科研诚信。作者身份以 SkillHub 平台展示信息为准；项目不收集私人 Token、内部路径或未授权数据。

## 发布

1. 在 SkillHub 个人中心创建 API Token。
2. 执行 `skillhub auth login --token skh_xxx` 或按当前 CLI 帮助登录。
3. 先生成 ZIP，并运行 `skillhub publish dist/evidence-grounded-materials-research-1.0.0.zip --dry-run`。
4. 确认版本、文件和变更说明后执行正式发布命令。

正式发布会产生外部公开内容，因此应由发布者在检查作者信息、许可证和引用后亲自确认执行。
